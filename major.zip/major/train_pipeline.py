# train_pipeline.py
# Usage: python train_pipeline.py --data path/to/dataset_phishing.csv --out models/
import argparse, os, re, joblib
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedShuffleSplit
from sklearn.metrics import roc_auc_score, classification_report
import scipy.sparse as sp

def simple_domain(host):
    if not host: return ''
    parts = host.split('.')
    if len(parts) <= 2: return '.'.join(parts)
    return '.'.join(parts[-2:])

def url_features(u):
    u = str(u)
    from urllib.parse import urlparse
    parsed = urlparse(u)
    host = parsed.hostname or ''
    dom = simple_domain(host)
    return {
        'url_len': len(u),
        'host_len': len(host),
        'domain_len': len(dom),
        'subdomain_count': 0 if host=='' else max(0, len(host.split('.'))-2),
        'count_dots': u.count('.'),
        'count_hyphen': u.count('-'),
        'count_at': u.count('@'),
        'num_q': u.count('?'),
        'num_eq': u.count('='),
        'num_slash': u.count('/'),
        'num_digits': sum(ch.isdigit() for ch in u),
        'has_ip': 1 if re.search(r'http[s]?:\\/\\/\\d+\\.\\d+\\.\\d+\\.\\d+', u) else 0,
        'https': 1 if u.lower().startswith('https') else 0,
        'susp_keyword': 1 if re.search(r'login|secure|account|update|verify|signin|bank|confirm|paypal|ebay', u, re.I) else 0
    }

def load_and_prepare(path):
    df = pd.read_csv(path, low_memory=False)
    # find likely url and label columns
    cols = df.columns.tolist()
    url_col = next((c for c in cols if re.search(r'url|link|website|site|web', c, re.I)), cols[0])
    label_col = next((c for c in cols if re.search(r'label|class|phish|phishing|result|status|type', c, re.I)), None)
    df['url'] = df[url_col].astype(str).str.strip()
    if label_col:
        df['label_raw'] = df[label_col]
        def map_label(x):
            if pd.isna(x): return np.nan
            s = str(x).strip().lower()
            if s in ['1','true','phishing','phish','bad','malicious','yes','y']: return 1
            if s in ['0','false','legitimate','benign','good','no','n']: return 0
            if 'phish' in s: return 1
            if 'legit' in s or 'benign' in s: return 0
            try:
                v = float(s); return 1 if v>0 else 0
            except: return np.nan
        df['label'] = df['label_raw'].apply(map_label)
    else:
        raise RuntimeError("No label column found.")
    df = df[['url','label']].dropna().drop_duplicates('url').reset_index(drop=True)
    return df

def main(args):
    outdir = args.out
    os.makedirs(outdir, exist_ok=True)
    df = load_and_prepare(args.data)
    print("Loaded", len(df), "rows. labels:", df['label'].value_counts().to_dict())

    # numeric features
    feats = [url_features(u) for u in df['url'].astype(str)]
    X_num = pd.DataFrame(feats).fillna(0)
    numeric_cols = X_num.columns.tolist()

    # TF-IDF on URL (char n-grams)
    corpus = df['url'].astype(str).apply(lambda u: u.split('//',1)[-1])
    tfv = TfidfVectorizer(analyzer='char_wb', ngram_range=(3,6), max_features=4000)
    X_tfidf = tfv.fit_transform(corpus)

    # combine
    X_comb = sp.hstack([sp.csr_matrix(X_num.values), X_tfidf]).tocsr()
    y = df['label'].astype(int).values

    # split
    sss = StratifiedShuffleSplit(n_splits=1, test_size=0.2, random_state=42)
    train_idx, test_idx = next(sss.split(X_comb, y))
    X_train, X_test = X_comb[train_idx], X_comb[test_idx]
    y_train, y_test = y[train_idx], y[test_idx]

    # logistic
    lr = LogisticRegression(max_iter=2000, class_weight='balanced', solver='saga', n_jobs=-1)
    lr.fit(X_train, y_train)
    y_proba_lr = lr.predict_proba(X_test)[:,1]
    print("Logistic AUC:", roc_auc_score(y_test, y_proba_lr))
    print("Logistic report:\n", classification_report(y_test, lr.predict(X_test), digits=4))

    # RandomForest
    rf = RandomForestClassifier(n_estimators=200, class_weight='balanced', n_jobs=-1, random_state=42)
    rf.fit(X_train, y_train)
    y_proba_rf = rf.predict_proba(X_test)[:,1]
    print("RF AUC:", roc_auc_score(y_test, y_proba_rf))
    print("RF report:\n", classification_report(y_test, rf.predict(X_test), digits=4))

    # save artifacts
    joblib.dump(tfv, os.path.join(outdir, "tfidf_vectorizer.joblib"))
    joblib.dump(numeric_cols, os.path.join(outdir, "numeric_columns.joblib"))
    joblib.dump(lr, os.path.join(outdir, "logistic_model.joblib"))
    joblib.dump(rf, os.path.join(outdir, "randomforest_model.joblib"))
    # save test predictions sample
    test_df = df.iloc[test_idx].copy().reset_index(drop=True)
    test_df['pred_lr_proba'] = y_proba_lr
    test_df['pred_lr'] = (y_proba_lr >= 0.5).astype(int)
    test_df['pred_rf_proba'] = y_proba_rf
    test_df['pred_rf'] = (y_proba_rf >= 0.5).astype(int)
    test_df.to_csv(os.path.join(outdir, "test_predictions_sample.csv"), index=False)
    print("Saved artifacts to", outdir)

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--data", required=True, help="path to CSV dataset")
    p.add_argument("--out", default="models", help="output folder")
    main(p.parse_args())
